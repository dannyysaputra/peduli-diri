

<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app.content'); ?>
    <p>Selamat datang <?php echo e(auth()->user()->name); ?> di aplikasi Peduli Diri</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danny\peduli-diri\resources\views/pages/home.blade.php ENDPATH**/ ?>