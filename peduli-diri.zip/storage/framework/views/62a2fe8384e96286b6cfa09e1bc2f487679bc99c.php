

<?php $__env->startSection('title'); ?>
    Input Tabel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app.content'); ?>
    <a href="/dashboard"><i class="fas fa-arrow-left"></i></a>
    <div class="flex items-center mt-4">
        <h2>Masukkan Data</h2>
    </div>
    <form method="POST" action="/buat-data" class="my-8">
        <?php echo csrf_field(); ?>
        <div class="mb-6">
            <label for="tanggal" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Tanggal</label>
            <input type="date" min="2020-02-27" name="tanggal" id="datePicker" class="block p-4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-3/4" value="<?php echo e(old('tanggal')); ?>" required>
        </div>
        <div class="mb-6">
            <label for="tanggal" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Jam</label>
            <input type="time" name="jam" class="block p-4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-3/4" value="<?php echo e(old('tanggal')); ?>" required>
        </div>
        <div class="mb-6">
            <label for="lokasi" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Lokasi</label>
            <input type="text" name="lokasi" id="lokasi" class="block p-4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-3/4" value="<?php echo e(old('lokasi')); ?>" required>
        </div>
        <div class="mb-6">
            <label for="suhu" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Suhu</label>
            <input type="number" min="32" max="40" name="suhu" id="suhu" class=" <?php $__errorArgs = ['suhu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> block p-4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-3/4" required value="<?php echo e(old('suhu')); ?>">
            <?php $__errorArgs = ['suhu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="flex items-center font-medium tracking-wide text-red-500 text-xs mt-1 ml-1">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
    </form>
    <script>
        // $( function() {
        //     $( "#datePicker" ).datepicker({                  
        //         maxDate: moment().add('d', 1).toDate(),
        //     });
        // } );
        datePicker.max = new Date().toISOString().split("T")[0];
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danny\peduli-diri\resources\views/pages/input-data.blade.php ENDPATH**/ ?>